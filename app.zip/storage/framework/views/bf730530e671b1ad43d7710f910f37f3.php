<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp\htdocs\Laravel\project-management-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>